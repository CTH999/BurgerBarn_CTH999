# Burger Barn
A simple general burger ordering program
does not need a readme